BDA400 Assignment 5 - Technical Analysis using R, Development Phase
Student: Navjot Singh

FILES
- sma.R
- ema.R
- macd.R
- stdev.R
- linreg.R
- rsi.R
- stoch_rsi.R
- crossover.R
- crossunder.R
- run_all_tests.R
- NavjotSingh_BDA400_A05.docx

HOW TO RUN
1. Put all files in the same Assignment5 folder.
2. Open the folder in RStudio or set it as the working directory.
3. Open run_all_tests.R.
4. Click Source.
5. Review the Console and confirm there are no unexpected errors.
6. You can also open and Source each indicator file separately.

IMPORTANT
The assignment requires manual verification. Run the scripts yourself before LMS submission.
Upload the work to your TechnicalAnalysis repository under Assignment5.
