# BDA400 Assignment 5 - Crossunder function
# Student: Navjot Singh
# Base R only.

crossunder <- function(arr1, arr2) {
  if (length(arr1) != length(arr2)) stop("Both arrays should have the same length")
  if (!is.numeric(arr1) || !is.numeric(arr2)) stop("Both arrays must be numeric")
  crossunder_signals <- rep("False", length(arr1))
  if (length(arr1) > 0) crossunder_signals[1] <- "None"
  if (length(arr1) >= 2) {
    for (i in 2:length(arr1)) {
      if (arr1[i] < arr2[i] && arr1[i - 1] >= arr2[i - 1]) crossunder_signals[i] <- "True"
    }
  }
  return(crossunder_signals)
}

# Test
arr1 <- c(10,12,15,20,18,22,25,24,21)
arr2 <- c(18,20,22,18,15,12,10,11,13)
print(crossunder(arr1, arr2))
