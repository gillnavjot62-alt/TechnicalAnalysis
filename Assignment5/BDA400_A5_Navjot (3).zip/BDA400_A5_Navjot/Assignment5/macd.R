# BDA400 Assignment 5 - Moving Average Convergence Divergence (MACD)
# Student: Navjot Singh
# Uses only base R functions. EMA logic is implemented locally; no libraries are used.

ema <- function(data, period) {
  multiplier <- 2 / (period + 1)
  values <- numeric(length(data))
  for (i in seq_along(data)) {
    if (i == 1) values[i] <- data[i]
    else values[i] <- (data[i] - values[i - 1]) * multiplier + values[i - 1]
  }
  values
}

macd <- function(data, short_period, long_period, signal_period) {
  if (!is.numeric(data) || length(data) == 0) stop("data must be a non-empty numeric vector")
  periods <- c(short_period, long_period, signal_period)
  if (any(periods < 1) || any(periods != as.integer(periods))) stop("periods must be positive integers")

  short_ema <- ema(data, short_period)
  long_ema <- ema(data, long_period)
  macd_line <- short_ema - long_ema
  signal_line <- ema(macd_line, signal_period)
  histogram <- macd_line - signal_line
  result <- list(macd_line = macd_line, signal_line = signal_line, histogram = histogram)
  return(result)
}

# Test
data <- c(100, 105, 110, 115, 120, 125, 130)
print(macd(data, 3, 5, 2))
