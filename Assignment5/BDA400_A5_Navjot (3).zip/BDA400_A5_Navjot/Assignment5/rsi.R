# BDA400 Assignment 5 - Relative Strength Index (RSI)
# Student: Navjot Singh
# Wilder-style smoothing; base R only.

rsi <- function(data, period) {
  if (!is.numeric(data) || length(data) < 2) stop("data must contain numeric values")
  if (period < 1 || period != as.integer(period)) stop("period must be a positive integer")
  if (length(data) <= period) stop("Data length must be greater than period")

  diff_values <- diff(data)
  gains <- numeric(length(diff_values))
  losses <- numeric(length(diff_values))
  for (i in seq_along(diff_values)) {
    if (diff_values[i] > 0) gains[i] <- diff_values[i]
    else if (diff_values[i] < 0) losses[i] <- abs(diff_values[i])
  }

  avg_gain <- sum(gains[1:period]) / period
  avg_loss <- sum(losses[1:period]) / period
  rsi_values <- rep(NA_real_, length(data))

  if (avg_loss == 0) rsi_values[period + 1] <- 100
  else {
    rs <- avg_gain / avg_loss
    rsi_values[period + 1] <- 100 - (100 / (1 + rs))
  }

  if (period + 2 <= length(data)) {
    for (i in (period + 2):length(data)) {
      avg_gain <- (avg_gain * (period - 1) + gains[i - 1]) / period
      avg_loss <- (avg_loss * (period - 1) + losses[i - 1]) / period
      if (avg_loss == 0) rsi_values[i] <- 100
      else {
        rs <- avg_gain / avg_loss
        rsi_values[i] <- 100 - (100 / (1 + rs))
      }
    }
  }
  return(rsi_values)
}

# Test
data <- c(45, 50, 48, 55, 52, 49, 58, 60, 65, 62, 66, 68, 64, 70, 72, 69, 75, 77)
print(rsi(data, 5))
