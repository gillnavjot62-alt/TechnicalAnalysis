# BDA400 Assignment 5 - Manual test runner
# Run this file from the Assignment5 folder.

files <- c("sma.R","ema.R","macd.R","stdev.R","linreg.R","rsi.R","stoch_rsi.R","crossover.R","crossunder.R")
for (f in files) {
  cat("\n==============================\n")
  cat("RUNNING:", f, "\n")
  cat("==============================\n")
  source(f)
}
cat("\nAll Assignment 5 scripts were sourced. Review the Console for errors.\n")
