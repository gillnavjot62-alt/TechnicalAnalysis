# BDA400 Assignment 5 - Stochastic RSI (StochRSI)
# Student: Navjot Singh
# Base R only. Includes local RSI and SMA helpers.

sma <- function(data, period) {
  if (length(data) < period) stop("Data length should be greater than or equal to the period")
  out <- numeric(length(data) - period + 1)
  for (i in 1:(length(data) - period + 1)) out[i] <- sum(data[i:(i + period - 1)]) / period
  out
}

rsi <- function(data, period) {
  if (length(data) <= period) stop("Data length must be greater than period")
  d <- diff(data); gains <- pmax(d, 0); losses <- pmax(-d, 0)
  ag <- sum(gains[1:period]) / period; al <- sum(losses[1:period]) / period
  out <- rep(NA_real_, length(data))
  out[period + 1] <- if (al == 0) 100 else 100 - 100 / (1 + ag / al)
  if (period + 2 <= length(data)) for (i in (period + 2):length(data)) {
    ag <- (ag * (period - 1) + gains[i - 1]) / period
    al <- (al * (period - 1) + losses[i - 1]) / period
    out[i] <- if (al == 0) 100 else 100 - 100 / (1 + ag / al)
  }
  out
}

stoch_rsi <- function(data, period, k_period, d_period) {
  if (!is.numeric(data)) stop("data must be numeric")
  rsi_values <- rsi(data, period)
  valid_rsi <- rsi_values[!is.na(rsi_values)]
  if (length(valid_rsi) < k_period) stop("Not enough RSI values for k_period")

  min_rsi <- min(valid_rsi)
  max_rsi <- max(valid_rsi)
  if (max_rsi == min_rsi) k_values <- rep(0, length(valid_rsi))
  else k_values <- (valid_rsi - min_rsi) / (max_rsi - min_rsi)

  k_line <- sma(k_values, k_period)
  if (length(k_line) < d_period) stop("Not enough %K values for d_period")
  d_line <- sma(k_line, d_period)
  result <- list(k_line = k_line, d_line = d_line)
  return(result)
}

# Test
data <- c(45,50,48,55,52,49,58,60,65,62,66,68,64,70,72,69,75,77,74,80,82,79,84,86)
print(stoch_rsi(data, 14, 3, 3))
